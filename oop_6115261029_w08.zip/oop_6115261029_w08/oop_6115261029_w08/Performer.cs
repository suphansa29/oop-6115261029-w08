﻿using System;
using System.Collections.Generic;
using System.Text;

namespace oop_6115261029_w08
{
    class Performer
    {
        private string name;
        private string nickname;
        private string birthday;
        private string age;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    
        public string Nickname
        {
            get { return nickname; }
            set { nickname = value; }
        }

        public string Birthday
        {
            get { return birthday; }
            set { birthday = value; }
        }
        public string Age
        {
            get { return age; }
            set { age = value; }
        }
        public Performer(string n, string nn, string bd, string a)
        {
            this.Name = n;
            this.Nickname = nn;
            this.Birthday = bd;
            this.Age = a;
        }
        public override string ToString()
        {
            return this.Name + " " +
                   this.Nickname + " " +
                   this.Birthday + " " +
                   this.Age;
        }
    }
   
}
