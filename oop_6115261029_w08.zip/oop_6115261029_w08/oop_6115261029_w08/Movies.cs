﻿using System;
using System.Collections.Generic;
using System.Text;

namespace oop_6115261029_w08
{
    class Movies
    {
        private string moviename;
        private string time;
        private string type;
        private string year;
        private Performer performerMovies;

        public string Moviename
        {
            get { return moviename; }
            set { moviename = value; }
        }

        public string Time
        {
            get { return time; }
            set { time = value; }
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        public string Year
        {
            get { return year; }
            set { year = value; }
        }
        public Performer PerformerMovies
        {
            get { return this.performerMovies  ; }
            set { performerMovies = value; }
        }
        public Movies (string mn, string t, string tp, string y, Performer pm)
        {
            this.Moviename = mn;
            this.time = t;
            this.Type = tp;
            this.year = y;
            this.PerformerMovies = pm;
        }
        public override string ToString()
        {
            return this.Moviename + " " +
                   this.time + " " +
                   this.Type + " " +
                   this.year + " " +
                   this.PerformerMovies.Nickname;
        }
    }

}
