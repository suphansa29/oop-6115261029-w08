﻿using System;

namespace oop_6115261029_w08
{
    class Program
    {
        static void Main(string[] args)
        {
            Performer p1 = new Performer("Sukonwat", "Weir", "18.04.2528", "35");
            Performer p2 = new Performer ("Ketsarin", "Pupae", "24.12.2542", "20");
            Movies m1 = new Movies ("Mekong River Side Love Song", "01.25.00", "Drama","2550",p1);
            Movies m2 = new Movies ("A hundred forest", "1.30.00", "Action", "2563",p2);
            Console.WriteLine(m1);
            Console.WriteLine(m2);
        }
    }
}
